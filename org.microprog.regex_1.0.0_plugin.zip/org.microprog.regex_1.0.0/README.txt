Regular Expression Editor Plugin

Authors:
---------
Maheshwaran.S , Indumathi.R, 
sona College of Technology, 
salem,
Tamilnadu,
India.

CONTACT:
--------
Maheshwaran.S	smahesh_monu@rediffmail.com
Indumathi.R	indu_ashwini@rediffmail.com

This editor is plugged with Jakarta-Oro Regular expression package. This provides the interface for the package. Jakarta-Oro's Perl, AWK and GLOB Expresions can be executed in this plugin. Many options such as "matching" , "containg", "Multi-Line", "Debug" etc. are avaiable

WORKING:
--------
	This plug-in opens a wizard for the editor file and creates a editor file with extension ".rx". But contents are not saved. then after creating a file, the editor opens and the user can do his job with it. Using the "compile&run" button, the user can check and verify the regular expression is matching with data.

	for more details of the expression visit jakarta site 

http://jakarta.apache.org/oro.


	for more details of the expression visit jakarta site http://jakarta.apache.org/oro.

